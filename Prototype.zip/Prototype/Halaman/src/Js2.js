
let ads = " ";
//alert(html1[0])
function inp1(){
  let doc = document.getElementById("input1").value;
  let ads
  const data = ["kimia", "fisika", "novel","aldi","hujan"];
  const input = doc;
  const hasilPencarian = [];

  for (let i = 0; i < data.length; i++) {
    if (data[i].includes(input)) {
        hasilPencarian.push(data[i]);
    }
  }
  if (hasilPencarian.length > 0) {
      console.log(`Hasil pencarian untuk "${input}": ${hasilPencarian.join(", ")}`);
  } else {
      console.log(`Tidak ada hasil pencarian untuk   "${input}".`);
  }
  doc = document.querySelectorAll('.buku');
  
  for (let i = 0; i < doc.length; i++) {
    doc[i].style.display = "none";
  }
  for(let j=0;j<hasilPencarian.length;j++){
    switch (hasilPencarian[j]){
      case "kimia":
        doc = document.getElementById("a0");
        doc.style.display="block";
        break;
      
      case "fisika":
      
        doc = document.getElementById("a1");
        doc.style.display="block";
        break;
      
      case "novel":
      
        doc = document.getElementById("a2");
        doc.style.display="block";
        break;
      case "aldi":
      
        doc = document.getElementById("a3");
      
        doc.style.display="block";
        break;
      case "hujan":
        doc = document.getElementById("a4");
      
        doc.style.display="block";
        break;
      default:
        break;
    }
  }
  
}
 