let html1 = ['<div class="buku" id="a0"><div class="box"></div><div class="gbuku"></div><text class="font">kimia</text></div>',
'<div class="buku" id="a1"><div class="box"></div><div class="gbuku"></div><text class="font">fisika</text></div>',
'<div class="buku" id="a2"><div class="box"></div><div class="gbuku"></div><text class="font">novel</text></div>',
'<div class="buku" id="a3"><div class="box"></div><div class="gbuku"></div><text class="font">aldi</text></div>',
'<div class="buku" id="a4"><div class="box"></div><div class="gbuku"></div><text class="font">hujan</text></div>'];